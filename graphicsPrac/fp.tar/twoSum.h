#ifndef TWOSUM_H
#define TWOSUM_H
#include <iostream>
#include <vector>
#include <string>

std::vector<int> addNumbers(std::vector<int> &numbers, int target);

#endif   
