#ifndef UTIL_H
#define UTIL_H

#include <GL/freeglut.h>
#include "event.h"
#include "callbacks.h"

void initOpenGL(int, char**, int, int);
void utilityCentral(Event *);

#endif
