#include "util.h"

int main(int argc, char** argv)
{
   initOpenGL(argc, argv, 600, 480);

   glutMainLoop();
   
   return 0;
}
